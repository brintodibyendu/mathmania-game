#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void itos(char a[],int b)
{
    int i = 0 ;
    while(b!=0)
    {
        a[i] = b%10 + '0' ;
        b = b/10 ;
        i++ ;
    }
    int l= i ;
    a[l] ='\0' ;
    char tem ;
    int j= l-1 ;
    for(i=0;i<l/2;i++)
    {
        tem = a[i] ;
        a[i] = a[j] ;
        a[j] = tem ;

        j-- ;
    }
}

void filemanagement(FILE *f, char a[],int score)
{
    char s[10] ;
    f = fopen("sample.txt" , "a" ) ;
    strcat(a,"\t") ;
    itos(s,score) ;
    strcat(a,s) ;
    strcat(a,"\n") ;
    fputs(a,f) ;
    fclose(f) ;
}

int main()
{
    FILE *f ;
    char a[80] ;
    gets(a) ;
    int b ;
    scanf("%d" ,&b) ;
    filemanagement(f,a,b) ;
    return 0 ;
}
