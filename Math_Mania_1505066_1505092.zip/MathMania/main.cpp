# include "iGraphics.h"
#include "texture.h"
#include <stdio.h>
#include <stdlib.h>

/* This program uses iCircle , iRectengel , iText , iSettimer from iGraphics.h ,
   sprintf , FILE functions from stdlib.h , Create texture and draw texture from texture.h
   and random funtions */
char str[100], str2[100]; //FILE Process 1st string takes input and 2nd string copies name from 1st string
char str3[100] ; //For File compares player score
int len; // sets length for string 1
int mode ; // changes player to section screen with the press of "Enter"
int se1,se2 ; //se1 to math series and se2 to equation soler
int x,y,z,r1,i,s=0,a=0,m=0,n=70,k=0,t,l,s1,s2,h,c=0,c1=21,x1,o1,o2,o3,x2=250,x3=240,l1=250,l2=30,l3=565,l4=190,x4=12,x5=240,y5=330,x6=260,m1=0,y6=180; //necessary variables
char ch5[9000],ch[9000],ch1[9000],ch2[9000],ch3[9000],ch4[9000],ch6[9000],ch8[9000],ch9[9000],ch10[9000],ch11[9000]; // necessary strings
void ti() // it decreases time set in the variable "n" by 700 ms by using iSetTimer Function
{
    n-- ;//to show time
}
void rand1()//random function for math series
{
    srand(time(NULL)); // For each run creates new variable
    x=(rand()%7)+1; // Series 1st element
    r1=(rand()%8); // randomly generates 1 equation from 8 set in iDraw()
    c1--; // c1 = total number of questions
}
void drawTextBox() // Creates name box for player name input screen
{
    iSetColor(256, 256, 256);
    iRectangle(x2, x3, l1, l2);
}

void mouseOver(int mx,int my) //print the co-ordinates of mouse position in the console
{
    printf("%d %d", mx,my) ;
}

void player() //this screen takes player name from the user
{
    drawTexture(0,0,pla) ; //texture for player screen
    drawTextBox();
    iSetColor(255, 255, 255);
    iText(l1+5, l1, str,GLUT_BITMAP_HELVETICA_18); //str = "player name"

}

void section()
{
    drawTexture(0,0,sec) ; //texture for section choosing
}

void iKeyboard(unsigned char key)
{
    if (key == 'q')
    {
        exit(0);
    }

    if((key == 'r' || key=='R') && se2==1 ) //Resets equation solver part
    {
        k=0 ; //
        n=70;//time
        s=0; //score
        c=0; // if the score is reasonable , generates complex equations if c==1 and it resets it .
    }
 if((key == 'r' || key=='R') && se1==1 ) //Resets series solver part
    {
        k=0 ;
        n=70;
        s=0;
        c=0;
        c1=21; // Number of questions in math series
    }
if((key == 's' || key=='S') && mode==1 ) //Resets series solver part
    {

        se1=0;
        se2=0;
        n=70;
        s=0;
        c=0;
        c1=21; // Number of questions in math series
    }
    if(key == '\r' ) //With the press of "Enter" , it stops taking character
    {
        mode = 1; // go to section page
        strcpy(str2, str); // string copies from string 1 to string 2
        printf("%s\n", str2); // prints player name in the console and ensures the input of player name
        for(i = 0; i < len; i++)
            str[i] = 0;
        len = 0; // resets player name character to zero
    }
    else
    {
        str[len] = key;
        len++;
    }
}
void ran()//random function for equation solver
{
    srand(time(NULL));
    r1=(rand()%4);
    x=(rand()%25)+1;
    y=(rand()%25)+1;
    z=(rand()%25)+1;
    l=(rand()%9)+1;
}
void equationhome() //generate equation solver home page
{
    drawTexture(0,0,ho) ;
    iSetColor(0,0,0) ;
    iText(l3,l4,"START", GLUT_BITMAP_TIMES_ROMAN_24) ;
    iText(l3,l4-30,"High Score", GLUT_BITMAP_TIMES_ROMAN_24) ;
    iText(l3,l4-60,"Exit", GLUT_BITMAP_TIMES_ROMAN_24) ;
}

void serieshome() //generates series solver home page
{
    drawTexture(0,0,sh) ;
    iSetColor(0,0,0) ;
    iText(l3-415,l4,"START", GLUT_BITMAP_TIMES_ROMAN_24) ;
    iText(l3-415,l4-30,"High Score", GLUT_BITMAP_TIMES_ROMAN_24) ;
    iText(l3-415,l4-60,"Exit", GLUT_BITMAP_TIMES_ROMAN_24) ;
}

void iDraw()
{
    iClear();
    if(mode==0)
    {
        player() ;//input player name
    }
    if(mode==1 && (k!=1 || k!=5))
    {
        section() ; // k=1 sends to equation solver and k=5 sends to math series
    }

    if(se2==1 && mode==1)
    {
        equationhome() ;
    }
    if(k==1 && se2==1) //Stars game in equation solver
    {
        drawTexture(0,0,mi) ;
        sprintf(ch,"%d",n);
        iText(400,10,"Press S to Switch and Press R to Main Menu") ;
        iText(x4,l3+13,ch,GLUT_BITMAP_HELVETICA_18);
        if(c==0) // //generates simple equations
        {
            //'t' generates results in the game
            if(r1==0)//for addition equation
            {
                t=x+y;
                sprintf(ch1,"%d",x);
                iText(x5,y5,ch1,GLUT_BITMAP_TIMES_ROMAN_24);
                sprintf(ch2,"%d",y);
                iText(x5+130,y5,ch2,GLUT_BITMAP_TIMES_ROMAN_24);
                sprintf(ch3,"%d",t);
                iText(x5+235,y5,ch3,GLUT_BITMAP_TIMES_ROMAN_24);
                iRectangle(x5+60,y5-3,x4+23,x4+8);
            }
            if(r1==1)//for substitution equation
            {
                //Changes if second variable is larger than 1st variable
                if(x>=y)
                {
                    t=x-y;
                }
                else
                {
                    t=y-x;
                }
                if(x<=y)
                {
                    x=x^y;
                    y=x^y;
                    x=x^y;
                }
                sprintf(ch1,"%d",x);
                iText(x5,y5,ch1,GLUT_BITMAP_TIMES_ROMAN_24);
                sprintf(ch2,"%d",y);
                iText(x5+130,y5,ch2,GLUT_BITMAP_TIMES_ROMAN_24);
                sprintf(ch3,"%d",t);
                iText(x5+235,y5,ch3,GLUT_BITMAP_TIMES_ROMAN_24);
                iRectangle(x5+60,y5-3,x4+23,x4+8);
            }
            if(r1==2)//for multiplication equation
            {
                t=x*y;
                 sprintf(ch1,"%d",x);
                iText(x5,y5,ch1,GLUT_BITMAP_TIMES_ROMAN_24);
                sprintf(ch2,"%d",y);
                iText(x5+130,y5,ch2,GLUT_BITMAP_TIMES_ROMAN_24);
                sprintf(ch3,"%d",t);
                iText(x5+235,y5,ch3,GLUT_BITMAP_TIMES_ROMAN_24);
                iRectangle(x5+60,y5-3,x4+23,x4+8);
            }
            if(r1==3)//for division equation
            {
                x=y*l;
                t=x/y;
                sprintf(ch1,"%d",x);
                iText(x5,y5,ch1,GLUT_BITMAP_TIMES_ROMAN_24);
                sprintf(ch2,"%d",y);
                iText(x5+130,y5,ch2,GLUT_BITMAP_TIMES_ROMAN_24);
                sprintf(ch3,"%d",t);
                iText(x5+235,y5,ch3,GLUT_BITMAP_TIMES_ROMAN_24);
                iRectangle(x5+60,y5-3,x4+23,x4+8);
            }
            if(s>250)
            {
                c=1;
            }
            iFilledRectangle(x5+185,y5+2,x4+8,x4-9); //down equals to sign
            iFilledRectangle(x5+185,y5+8,x4+8,x4-9); //up equals to sign
        }
        if(c==1) // generates
        {
            if(r1==0)//equation 5
            {
                t=(x+y)*z;
                sprintf(ch1,"%d",x);
                iText(x5,y5,ch1,GLUT_BITMAP_TIMES_ROMAN_24);
                iText(x5-15,y5,"(",GLUT_BITMAP_TIMES_ROMAN_24);
                sprintf(ch2,"%d",y);
                iText(x5+100,y5,ch2,GLUT_BITMAP_TIMES_ROMAN_24);
                iText(x5+60,y5,"+",GLUT_BITMAP_TIMES_ROMAN_24);
                sprintf(ch6,"%d",z);
                iText(x5+185,y5,ch6,GLUT_BITMAP_TIMES_ROMAN_24);
                sprintf(ch3,"%d",t);
                iText(x5+145,y5,")",GLUT_BITMAP_TIMES_ROMAN_24);
                iText(x5+270,y5,ch3,GLUT_BITMAP_TIMES_ROMAN_24);
            }
            if(r1==1)//equation 6
            {
                if(y>=x)
                {
                    y=x^y;
                    x=x^y;
                    y=x^y;
                }
                x=(l*z)+y;
                t=(x-y)/z;
                sprintf(ch1,"%d",x);
                iText(x5,y5,ch1,GLUT_BITMAP_TIMES_ROMAN_24);
                iText(x5-15,y5,"(",GLUT_BITMAP_TIMES_ROMAN_24);
                sprintf(ch2,"%d",y);
                iText(x5+100,y5,ch2,GLUT_BITMAP_TIMES_ROMAN_24);
                iText(x5+145,y5,")",GLUT_BITMAP_TIMES_ROMAN_24);
                iText(x5+165,y5,"/",GLUT_BITMAP_TIMES_ROMAN_24);
                sprintf(ch6,"%d",z);
                iText(x5+185,y5,ch6,GLUT_BITMAP_TIMES_ROMAN_24);
                sprintf(ch3,"%d",t);
                iText(x5+270,y5,ch3,GLUT_BITMAP_TIMES_ROMAN_24);
            }
            if(r1==2)//equation 7
            {
                y=l*z;
                t=x*(y/z);
                sprintf(ch1,"%d",x);
                iText(x5,y5,ch1,GLUT_BITMAP_TIMES_ROMAN_24);
                iText(x5+60,y5,"x",GLUT_BITMAP_TIMES_ROMAN_24);
                sprintf(ch2,"%d",y);
                iText(x5+100,y5,ch2,GLUT_BITMAP_TIMES_ROMAN_24);
                iText(x5+90,y5,"(",GLUT_BITMAP_TIMES_ROMAN_24);
                sprintf(ch6,"%d",z);
                iText(x5+185,y5,ch6,GLUT_BITMAP_TIMES_ROMAN_24);
                sprintf(ch3,"%d",t);
                iText(x5+210,y5,")",GLUT_BITMAP_TIMES_ROMAN_24);
                iText(x5+270,y5,ch3,GLUT_BITMAP_TIMES_ROMAN_24);
            }
            if(r1==3)//equation 8
            {
                x=(y+z)*l;
                t=x/(y+z);
                sprintf(ch1,"%d",x);
                iText(x5,y5,ch1,GLUT_BITMAP_TIMES_ROMAN_24);
                iText(x5+60,y5,"/",GLUT_BITMAP_TIMES_ROMAN_24);
                sprintf(ch2,"%d",y);
                iText(x5+90,y5,"(",GLUT_BITMAP_TIMES_ROMAN_24);
                iText(x5+100,y5,ch2,GLUT_BITMAP_TIMES_ROMAN_24);
                sprintf(ch6,"%d",z);
                iText(x5+185,y5,ch6,GLUT_BITMAP_TIMES_ROMAN_24);
                sprintf(ch3,"%d",t);
                iText(x5+210,y5,")",GLUT_BITMAP_TIMES_ROMAN_24);
                iText(x5+270,y5,ch3,GLUT_BITMAP_TIMES_ROMAN_24);
            }
            iFilledRectangle(x5+235,y5+2,20,3);
            iFilledRectangle(x5+235,y5+8,20,3);
        }
        iSetColor(0,0,255);
        iCircle(x5+40,l4-5,20);
        iCircle(x5+100,l4-5,20);
        iCircle(x5+160,l4-5,20);
        iCircle(x5+220,l4-5,20);
        iSetColor(255,255,255);
        iText(x5+35,l4-10,"+",GLUT_BITMAP_HELVETICA_18);
        iText(x5+95,l4-10,"-",GLUT_BITMAP_HELVETICA_18);
        iText(x5+155,l4-10,"*",GLUT_BITMAP_HELVETICA_18);
        iText(x5+215,l4-10,"/",GLUT_BITMAP_HELVETICA_18);
        sprintf(ch4,"SCORE: %d",s);
        iText(l3+110,l3+15,ch4,GLUT_BITMAP_HELVETICA_18);
        iText(x4-2,x4+8,"PRESS Q TO QUIT");
        if(n<=0)
        {
            FILE *f1;
            f1=fopen("score.txt","r");
            fscanf(f1,"%s %d",str3, &s2);
            fclose(f1);
            if(s>=s2)//input highscore for equation solver
            {
                free(f1);
                f1=fopen("score.txt","w");
                fprintf(f1,"%s %d", str2, s) ;
                fclose(f1);
            }
            iShowBMP(0,0,"game over.bmp") ;
            iText(x4+28,x4+48,"Press R to start again") ;
        }
    }
    if(k==2 && se2==1 )//show highscore for equation solver
    {
        FILE *f1;
        f1=fopen("score.txt","r");
        fscanf(f1,"%s %d",str3,&s1);
        iShowBMP(0,0,"score.bmp") ;
        sprintf(ch5,"%d",s1);
        iSetColor(0,0,0) ;
        iText(x5+16,y5+45,str3,GLUT_BITMAP_TIMES_ROMAN_24);
        iText(x5-40,x4-2,"Press R to return to main menu") ;
        iText(x5+210,y5+45,ch5,GLUT_BITMAP_TIMES_ROMAN_24);
        fclose(f1);
    }
    if(se1==1 && mode==1 ) // series part
    {
        iClear();
        serieshome() ;
        if(k==5) // generates series player screen
        {
            drawTexture(0,0,sp) ;
            iSetColor(256,256,256);
            iText(400,10,"Press S to Switch and Press R to Main Menu") ;
            sprintf(ch,"%d",n);
            iText(x4,l3+13,ch,GLUT_BITMAP_HELVETICA_18);

            //randomly generates equation from by using random function

            if(r1==0)//series 1
            {
                sprintf(ch1,"%d",x);
                iText(x5,y5,ch1,GLUT_BITMAP_TIMES_ROMAN_24);
                y=(2*x)+3;
                sprintf(ch2,"%d",y);
                iRectangle(y5-10,y5,x4+18,x4+3);
                z=(2*y)+3;
                sprintf(ch6,"%d",z);
                iText(x5+y6,y5,ch6,GLUT_BITMAP_TIMES_ROMAN_24);
                t=(2*z)+3;
                sprintf(ch3,"%d",t);
                o1=(2*x);
                o2=(2*x)-3;
                o3=(3*x);
                sprintf(ch8,"%d",o1);
                sprintf(ch9,"%d",o2);
                sprintf(ch10,"%d",o3);
                iText(x5+240,y5,ch3,GLUT_BITMAP_TIMES_ROMAN_24);
                iText(x5+20,y6,ch9,GLUT_BITMAP_HELVETICA_18);
                iText(x5+110,y6,ch8,GLUT_BITMAP_HELVETICA_18);
                iText(x5+200,y6,ch2,GLUT_BITMAP_HELVETICA_18);
                iText(x5+290,y6,ch10,GLUT_BITMAP_HELVETICA_18);
                if(m1==1) //hint
                {
                    iText(y5-25,y5+80,"multiply 2 and add 3",GLUT_BITMAP_HELVETICA_12);
                }
            }
            if(r1==1)//series 2
            {
                sprintf(ch1,"%d",x);
                iText(x3,y5,ch1,GLUT_BITMAP_TIMES_ROMAN_24);
                y=(3*x)-1;
                iRectangle(400,y5,30,15);
                z=(3*y)-1;
                sprintf(ch2,"%d",z);
                sprintf(ch6,"%d",y);
                iText(320,y5,ch6,GLUT_BITMAP_TIMES_ROMAN_24);
                t=(3*z)-1;
                sprintf(ch3,"%d",t);
                iText(480,y5,ch3,GLUT_BITMAP_TIMES_ROMAN_24);
                o1=(2*y);
                o2=(2*y)+5;
                o3=(z)-13;
                sprintf(ch8,"%d",o1);
                sprintf(ch9,"%d",o2);
                sprintf(ch10,"%d",o3);
                iText(x6,y6,ch2,GLUT_BITMAP_HELVETICA_18);
                iText(x6+90,y6,ch9,GLUT_BITMAP_HELVETICA_18);
                iText(x6+y6,y6,ch8,GLUT_BITMAP_HELVETICA_18);
                iText(x6+270,y6,ch10,GLUT_BITMAP_HELVETICA_18);
                if(m1==1)//hint
                {
                    iText(y5-25,y5+80,"multiply 3 and sub 1",GLUT_BITMAP_HELVETICA_12);
                }
            }
            if(r1==2)//series 3
            {
                sprintf(ch1,"%d",x);
                iText(x3,y5,ch1,GLUT_BITMAP_TIMES_ROMAN_24);
                y=(5*x)+1;
                iRectangle(480,y5,30,15);
                z=(5*y)+1;
                sprintf(ch6,"%d",y);
                iText(320,y5,ch6,GLUT_BITMAP_TIMES_ROMAN_24);
                t=(5*z)+1;
                sprintf(ch3,"%d",z);
                sprintf(ch2,"%d",t);
                iText(400,y5,ch3,GLUT_BITMAP_TIMES_ROMAN_24);
                o1=t-9;
                o2=t+9;
                o3=t-17;
                sprintf(ch8,"%d",o1);
                sprintf(ch9,"%d",o2);
                sprintf(ch10,"%d",o3);
                iText(x6,y6,ch10,GLUT_BITMAP_HELVETICA_18);
                iText(x6+90,y6,ch9,GLUT_BITMAP_HELVETICA_18);
                iText(x6+y6,y6,ch8,GLUT_BITMAP_HELVETICA_18);
                iText(x6+270,y6,ch2,GLUT_BITMAP_HELVETICA_18);
                if(m1==1)//hint
                {
                    iText(y5-25,y5+80,"multiply 5 and add 1",GLUT_BITMAP_HELVETICA_12);
                }
            }
            if(r1==3)//series 4
            {
                sprintf(ch2,"%d",x);
                iText(480,y5,ch1,GLUT_BITMAP_TIMES_ROMAN_24);
                y=((-5)*x)+4;
                iRectangle(x3,y5,30,15);
                z=((-5)*y)+4;
                sprintf(ch6,"%d",y);
                iText(320,y5,ch6,GLUT_BITMAP_TIMES_ROMAN_24);
                t=((-5)*z)+4;
                sprintf(ch3,"%d",z);
                sprintf(ch1,"%d",t);
                iText(400,y5,ch3,GLUT_BITMAP_TIMES_ROMAN_24);
                o1=((-3)*x)-7;
                o2=((-5)*x);
                o3=x-3;
                sprintf(ch8,"%d",o1);
                sprintf(ch9,"%d",o2);
                sprintf(ch10,"%d",o3);
                iText(x6,y6,ch10,GLUT_BITMAP_HELVETICA_18);
                iText(x6+90,y6,ch2,GLUT_BITMAP_HELVETICA_18);
                iText(x6+y6,y6,ch8,GLUT_BITMAP_HELVETICA_18);
                iText(x6+270,y6,ch9,GLUT_BITMAP_HELVETICA_18);
                if(m1==1)//series 5
                {
                    iText(y5-25,y5+80,"multiply -5 and add 4",GLUT_BITMAP_HELVETICA_12);
                }
            }
            if(r1==4)
            {
                x1=(x*(x+1)*(x+2))/6; // n*(n+1)/2 type equation
                y=((x+1)*(x+2)*(x+3))/6;
                iRectangle(400,y5,30,15);
                z=((x+2)*(x+3)*(x+4))/6;
                sprintf(ch2,"%d",z);
                t=((x+3)*(x+4)*(x+5))/6;
                sprintf(ch6,"%d",y);
                sprintf(ch3,"%d",t);
                sprintf(ch1,"%d",x1);
                iText(320,y5,ch6,GLUT_BITMAP_TIMES_ROMAN_24);
                iText(480,y5,ch3,GLUT_BITMAP_TIMES_ROMAN_24);
                iText(x3,y5,ch1,GLUT_BITMAP_TIMES_ROMAN_24);
                o1=z-5;
                o2=z+7;
                o3=z+2;
                sprintf(ch8,"%d",o1);
                sprintf(ch9,"%d",o2);
                sprintf(ch10,"%d",o3);
                iText(x6,y6,ch8,GLUT_BITMAP_HELVETICA_18);
                iText(x6+90,y6,ch9,GLUT_BITMAP_HELVETICA_18);
                iText(x6+y6,y6,ch2,GLUT_BITMAP_HELVETICA_18);
                iText(x6+270,y6,ch10,GLUT_BITMAP_HELVETICA_18);
                if(m1==1)
                {
                    iText(y5-25,y5+80,"(n*(n+1)*(n*2)/6)",GLUT_BITMAP_HELVETICA_12);
                }
            }
            if(r1==5)//series 6
            {
                y=((-2)*x)-3;
                iRectangle(480,y5,30,15);
                z=((-2)*y)-3;
                t=((-2)*z)-3;
                sprintf(ch6,"%d",y);
                sprintf(ch3,"%d",z);
                sprintf(ch1,"%d",x);
                sprintf(ch2,"%d",t);
                iText(320,y5,ch6,GLUT_BITMAP_TIMES_ROMAN_24);
                iText(400,y5,ch3,GLUT_BITMAP_TIMES_ROMAN_24);
                iText(x3,y5,ch1,GLUT_BITMAP_TIMES_ROMAN_24);
                o1=z+5;
                o2=(-3)*z;
                o3=t-9;
                sprintf(ch8,"%d",o1);
                sprintf(ch9,"%d",o2);
                sprintf(ch10,"%d",o3);
                iText(x6,y6,ch2,GLUT_BITMAP_HELVETICA_18);
                iText(x6+90,y6,ch8,GLUT_BITMAP_HELVETICA_18);
                iText(x6+y6,y6,ch9,GLUT_BITMAP_HELVETICA_18);
                iText(x6+270,y6,ch10,GLUT_BITMAP_HELVETICA_18);
                if(m1==1)
                {
                    iText(y5-25,y5+80,"multiply -2 and sub 3",GLUT_BITMAP_HELVETICA_12);
                }
            }
            if(r1==6)//series 7
            {
                x1=((x)*(x+1))/2;
                sprintf(ch2,"%d",x1);
                y=((x+1)*(x+2))/2;
                iRectangle(x3,y5,30,15);
                z=((x+2)*(x+3))/2;
                t=((x+3)*(x+4))/2;
                sprintf(ch6,"%d",y);
                sprintf(ch3,"%d",z);
                sprintf(ch1,"%d",t);
                iText(320,y5,ch6,GLUT_BITMAP_TIMES_ROMAN_24);
                iText(400,y5,ch3,GLUT_BITMAP_TIMES_ROMAN_24);
                iText(480,y5,ch1,GLUT_BITMAP_TIMES_ROMAN_24);
                o1=x1+5;
                o2=x1+9;
                o3=x1-1;
                sprintf(ch8,"%d",o1);
                sprintf(ch9,"%d",o2);
                sprintf(ch10,"%d",o3);
                iText(x6,y6,ch9,GLUT_BITMAP_HELVETICA_18);
                iText(x6+90,y6,ch8,GLUT_BITMAP_HELVETICA_18);
                iText(x6+y6,y6,ch2,GLUT_BITMAP_HELVETICA_18);
                iText(x6+270,y6,ch10,GLUT_BITMAP_HELVETICA_18);
                if(m1==1)
                {
                    iText(y5-25,y5+80,"(n*(n+1))/2",GLUT_BITMAP_HELVETICA_12);
                }
            }
            if(r1==7)//series 8
            {
                y=((-4)*x)+3;
                sprintf(ch2,"%d",y);
                iRectangle(320,y5,30,15);
                z=((-4)*y)+3;
                t=((-4)*z)+3;
                sprintf(ch6,"%d",x);
                sprintf(ch3,"%d",z);
                sprintf(ch1,"%d",t);
                iText(x3,y5,ch6,GLUT_BITMAP_TIMES_ROMAN_24);
                iText(y5+70,y5,ch3,GLUT_BITMAP_TIMES_ROMAN_24);
                iText(y5+150,y5,ch1,GLUT_BITMAP_TIMES_ROMAN_24);
                o1=x*(-4);
                o2=x*(-2);
                o3=(x*(-2))+1;
                sprintf(ch8,"%d",o1);
                sprintf(ch9,"%d",o2);
                sprintf(ch10,"%d",o3);
                iText(x6,y6,ch10,GLUT_BITMAP_HELVETICA_18);
                iText(x6+90,y6,ch8,GLUT_BITMAP_HELVETICA_18);
                iText(x6+y6,y6,ch9,GLUT_BITMAP_HELVETICA_18);
                iText(x6+270,y6,ch2,GLUT_BITMAP_HELVETICA_18);
                if(m1==1)
                {
                    iText(y5-25,y5+80,"multiply -4 and add 3",GLUT_BITMAP_HELVETICA_12);
                }
            }
            iRectangle(y5+10,y5+130,x4+58,x4+18);
            iText(y5+15,y5+135,"HINT",GLUT_BITMAP_HELVETICA_18);
            sprintf(ch11,"QUESTION: %d",c1);
            iText(y5+20,l3+10,ch11,GLUT_BITMAP_HELVETICA_18);
            sprintf(ch4,"SCORE: %d",s);
            iText(l3+110,580,ch4,GLUT_BITMAP_HELVETICA_18);
            iCircle(x2+10,l4-5,40);
            iCircle(x2+100,l4-5,40);
            iCircle(x2+190,l4-5,40);
            iCircle(x2+280,l4-5,40);
            if(n<=0 || c1<=0)// input highscore for math series
            {
                FILE *f2;
                f2=fopen("sscore.txt","r");
                fscanf(f2,"%s %d",str3, &s1);
                fclose(f2);
                if(s>=s1)
                {
                    free(f2);
                    f2=fopen("sscore.txt","w");
                    fprintf(f2,"%s %d", str2, s) ;
                    fclose(f2);
                }
                iShowBMP(0,0,"game over.bmp") ;
                iText(x4+28,x4+48,"Press R to start again") ;
            }
        }
    }
    if(k==3 && se1==1)//show highscore for math series
    {
        iClear();
        FILE *f2;
        f2=fopen("sscore.txt","r");
        fscanf(f2,"%s %d",str3,&s1);
        iShowBMP(0,0,"score.bmp") ;
        sprintf(ch5,"%d",s1);
        iSetColor(0,0,0) ;
        iText(x5+16,y5+45,str3,GLUT_BITMAP_TIMES_ROMAN_24);
        iText(x5-40,x4-10,"Press R to return to main menu") ;
        iText(x5+210,y5+45,ch5,GLUT_BITMAP_TIMES_ROMAN_24);
        fclose(f2);
    }
}
void iMouseMove(int mx, int my)
{
    printf("x = %d, y= %d\n",mx,my);
}
void iMouse(int button, int state, int mx, int my)
{
    if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN && (mx>=120 && mx<=310 && my>=400 && my<=590) && mode==1)
    {
        se1= 1 ; //for series
    }

    if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN && (mx>=450 && mx<=640 && my>=99 && my<=285) && mode==1)
    {
        se2= 1 ;//for equation solver
    }

    if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN && (mx>=150 && mx<=x3 && my>=190 && my<=220) && se1== 1)
    {
        k=5 ;// 5 to start series
        rand1();
    }

    if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN && (mx>=565 && mx<=650 && my>=190 && my<=220) && se2== 1)
    {
        k=1 ;//1 to start equation solver
        ran();//start
        //PlaySound("start.wav", NULL, SND_ASYNC);
    }
    if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN && (mx>=570 && mx<=600 && my>=130 && my<=150))
    {
        exit(1);//quit
    }
    if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN && (mx>=565 && mx<=675 && my>=160 && my<=y6))
    {
        k=2;//highscore for equation solver
    }
    if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN && (mx>=150 && mx<=250 && my>=160 && my<=175) && se1==1)
    {
        k=3;//highscore for math series
    }
    if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN && (mx>=150 && mx<=190 && my>=130 && my<=145) && se1==1)
    {
        exit(1);//exit for math series
    }
    if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN && (mx>=340 && mx<=410 && my>=460 && my<=490) && se1==1)
    {
        m1=1;//show hint
    }
    if(c==0)
    {
        //simple equation control
        if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN && ((mx>=260 && mx<=300) || (mx>=320 && mx<=360) || (mx>=380 && mx<=420) || (mx>=440 && mx<=480))&& (my>=165 && my<=205) && k==1)
        {
            if(r1==0 && (mx>=x6 && mx<=300 && my>=165 && my<=205) && k==1)//equation1
            {
                n=n+5;
                s=s+50;
                PlaySound("cheer.wav", NULL, SND_ASYNC);
            }
            if(r1==1 && (mx>=320 && mx<=360 && my>=165 && my<=205) && k==1)//equation2
            {
                n=n+5;
                s=s+50;
                PlaySound("cheer.wav", NULL, SND_ASYNC);
            }
            if(r1==2 && (mx>=380 && mx<=420 && my>=165 && my<=205) && k==1)//equation3
            {
                n=n+5;
                s=s+50;
                PlaySound("cheer.wav", NULL, SND_ASYNC);
            }
            if(r1==3 && (mx>=440 && mx<=480 && my>=165 && my<=205) && k==1)//equation4
            {
                n=n+5;
                s=s+50;
                PlaySound("cheer.wav", NULL, SND_ASYNC);
            }
            //answer if wrong
            if(r1!=3 && (mx>=440 && mx<=480 && my>=165 && my<=205)&& k==1)
            {
                n=n-10;
                s=s-50;
                PlaySound("Slap.wav", NULL, SND_ASYNC);
            }
            if(r1!=2 && (mx>=380 && mx<=420 && my>=165 && my<=205)&& k==1)
            {
                n=n-10;
                s=s-50;
                PlaySound("Slap.wav", NULL, SND_ASYNC);
            }
            if(r1!=1 && (mx>=320 && mx<=360 && my>=165 && my<=205)&& k==1)
            {
                n=n-10;
                s=s-50;
                PlaySound("Slap.wav", NULL, SND_ASYNC);
            }
            if(r1!=0 && (mx>=x6 && mx<=300 && my>=165 && my<=205)&& k==1)
            {
                n=n-10;
                s=s-50;
                PlaySound("Slap.wav", NULL, SND_ASYNC);
            }
            ran();
        }
    }
    if(c==1)
    {
        //complex equation control
        if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN && ((mx>=260 && mx<=300) || (mx>=320 && mx<=360) || (mx>=380 && mx<=420) || (mx>=440 && mx<=480))&& (my>=165 && my<=205))
        {
            if(r1==0 && mx>=380 && mx<=420 && my>=165 && my<=205)//equation5
            {
                n=n+10;
                s=s+50;
                PlaySound("cheer.wav", NULL, SND_ASYNC);
            }
            if(r1==1 && mx>=320 && mx<=360 && my>=165 && my<=205)//equation6
            {
                n=n+10;
                s=s+50;
                PlaySound("cheer.wav", NULL, SND_ASYNC);
            }
            if(r1==2 && mx>=440 && mx<=480 && my>=165 && my<=205)//equation7
            {
                n=n+10;
                s=s+50;
                PlaySound("cheer.wav", NULL, SND_ASYNC);
            }
            if(r1==3 && mx>=x6 && mx<=300 && my>=165 && my<=205)//equation8
            {
                n=n+10;
                s=s+50;
                PlaySound("cheer.wav", NULL, SND_ASYNC);
            }
            //anser if wrong
            if((r1!=0) && (mx>=380 && mx<=420 && my>=165 && my<=205))
            {
                n=n-10;
                s=s-50;
                PlaySound("Slap.wav", NULL, SND_ASYNC);
            }
            if(r1!=1 && (mx>=320 && mx<=360 && my>=165 && my<=205))
            {
                n=n-10;
                s=s-50;
                PlaySound("Slap.wav", NULL, SND_ASYNC);
            }
            if((r1!=2) && (mx>=440 && mx<=480 && my>=165 && my<=205))
            {
                n=n-10;
                s=s-50;
                PlaySound("Slap.wav", NULL, SND_ASYNC);
            }
            if((r1!=3) && (mx>=x6 && mx<=300 && my>=165 && my<=205))
            {
                n=n-10;
                s=s-50;
                PlaySound("Slap.wav", NULL, SND_ASYNC);
            }
            ran();
        }
    }
    if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN &&(( mx>=400 && mx<=480)||( mx>=220 && mx<=300)||(mx>=490 && mx<=570)||(mx>=310 && mx<=390)) && (my>=145 && my<=225) && se1==1)
    {
        //control of math series
        if(r1==0 && mx>=400 && mx<=480 && my>=145 && my<=225 && se1==1)
        {
            s=s+50;
            PlaySound("cheer.wav", NULL, SND_ASYNC);
        }
        if(r1==1 &&  mx>=220 && mx<=300 && my>=145 && my<=225 && se1==1)
        {
            s=s+50;
            PlaySound("cheer.wav", NULL, SND_ASYNC);
        }
        if(r1==2 && mx>=490 && mx<=570 && my>=145 && my<=225 && se1==1)
        {
            s=s+50;
            PlaySound("cheer.wav", NULL, SND_ASYNC);
        }
        if(r1==3 &&  mx>=310 && mx<=390 && my>=145 && my<=225 && se1==1)
        {
            s=s+50;
            PlaySound("cheer.wav", NULL, SND_ASYNC);
        }
        if(r1==4 && mx>=400 && mx<=480 && my>=145 && my<=225 && se1==1)
        {
            s=s+50;
            PlaySound("cheer.wav", NULL, SND_ASYNC);
        }
        if(r1==5 && mx>=220 && mx<=300 && my>=145 && my<=225 && se1==1)
        {
            s=s+50;
            PlaySound("cheer.wav", NULL, SND_ASYNC);
        }
        if(r1==6 && mx>=400 && mx<=480 && my>=145 && my<=225 && se1==1)
        {
            s=s+50;
            PlaySound("cheer.wav", NULL, SND_ASYNC);
        }
        if(r1==7 && mx>=490 && mx<=570 && my>=145 && my<=225 && se1==1)
        {
            s=s+50;
            PlaySound("cheer.wav", NULL, SND_ASYNC);
        }
        m1=0;//hint
        rand1();
    }
    if (button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN)
    {
    }
}
void iSpecialKeyboard(unsigned char key)
{

    if (key == GLUT_KEY_END)
    {
        exit(0);
    }
}


int main()
{
    len = 0;
    mode = 0;
    str[0]= 0;
    iSetTimer(700,ti);
    PlaySound("start.wav", NULL, SND_ASYNC);
    iInitialize(800, 600, "demo");
    return 0;
}
