#include "texture.h"

texture ho;
texture mi;
texture pla ;
texture sec ;
texture sh ;
texture sp ;
void textureInit()
{
    sp.Create("math2.bmp") ;
    sh.Create("math1.bmp") ;
    sec.Create("section choose.bmp") ;
    pla.Create("player.bmp") ;
	ho.Create("Home.bmp");
	mi.Create("play screen.bmp") ;
}
